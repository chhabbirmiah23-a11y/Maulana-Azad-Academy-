MAULANA AZAD ACADEMY WEBSITE
==============================

Files:
- index.html : main website
- style.css  : design
- assets/    : uploaded school photographs

How to use:
1. Open index.html in a browser to preview.
2. Upload the whole folder to a web host to publish it.
3. Edit index.html to change notices, teachers, text, or contact details.

School details included:
Address: Narai, Gangarampur, Dakshin Dinajpur, West Bengal – 733124
Phone: +91 76999 15960 / +91 90020 03165
Headmaster/Principal: Mostak Hossain Mondal
Office Staff: Chhabbir Miah
Facebook: https://www.facebook.com/share/1MQr2aGyPp/
